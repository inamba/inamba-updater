<?php

namespace iThemesSecurity\Exception;

class Invalid_Module extends \Exception implements Exception {

}
