<?php

return [
	'title' => __( 'Brute Force', 'it-l10n-ithemes-security-pro' ),
];
