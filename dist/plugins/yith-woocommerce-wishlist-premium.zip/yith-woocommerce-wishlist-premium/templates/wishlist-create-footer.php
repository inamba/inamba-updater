<?php
/**
 * Wishlist create footer template
 *
 * @author YITH
 * @package YITH\Wishlist\Templates\Wishlist\Create
 * @version 3.0.0
 */

if ( ! defined( 'YITH_WCWL' ) ) {
	exit;
} // Exit if accessed directly
?>

	<?php do_action( 'yith_wcwl_after_wishlist_create' ); ?>
</form>
