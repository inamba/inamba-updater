Inamba Private
======

[![Author](https://img.shields.io/badge/Autor-Inamba-009fdf)](#readme) 
[![License](https://img.shields.io/badge/License-MIT-green)](#readme) 

<br>
<br>

Complemento para <strong>Inamba</strong> que protege el sitio público solicitando que los visitantes inicien sesión previamente. También guarda registros de los intentos de acceso.








<br>
<br>
<br>


###### Copyright 2011-2022 © [Inamba](https://inamba.com/).