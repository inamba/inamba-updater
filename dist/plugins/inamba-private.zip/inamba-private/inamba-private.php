<?php
	
	/*
	
	Plugin Name: 				Inamba Private
	Description: 				Inamba Private is a plugin for developers.
	Version: 					5.0
	Stable tag: 				4.0
	Author: 					Inamba
	Author URI: 				https://inamba.com/
	License: 					MIT
	License URI: 				https://opensource.org/licenses/MIT
	Text Domain: 				inamba-private
	Domain Path:				/languages/
	Requires at least: 			5.9
	Tested up to: 				6.0.2
	
	@package:					InambaPrivate
	@copyright:					2022 © Inamba
	@support:					https://market.inamba.com/
	@updated:					2023-01-24 12:11
	@email:						market@inamba.com
	@comments:					
	
	@github:					https://github.com/inamba/framework
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	define('__INAMBAPRIVATE__', true);
	define('__INAMBAPRIVATE_PATH__', plugin_dir_path(__FILE__));
	define('__INAMBAPRIVATE_URL__', plugin_dir_url(__FILE__));
	define('__INAMBAPRIVATE_NAME__', 'Inamba Private');
	define('__INAMBAPRIVATE_NAMESPACE__', 'inamba-private');
	define('__INAMBAPRIVATE_SLUG__', 'inambaprivate');
	define('__INAMBAPRIVATE_ADMINPATH__', 'admin.php?page='.__INAMBAPRIVATE_SLUG__);
	define('__INAMBAPRIVATE_FOLDER__', plugin_basename(dirname(__FILE__)));
	define('__INAMBAPRIVATE_FILENAME__', plugin_basename(__FILE__));
	
	if(get_option(__INAMBAPRIVATE_SLUG__.'_version') !== false){
		define('__INAMBAPRIVATE_VERSION__', get_option(__INAMBAPRIVATE_SLUG__.'_version'));
	}
	
	define('__INAMBAPRIVATE_REDIRECT_SUFFIX__', __INAMBAPRIVATE_SLUG__.'=autentication');
	
	/*
	
	CONFIG
	----------------------------------------------------------------------------------------
	
	*/
	
	if($_SERVER['HTTP_HOST'] === 'localhost:8888'){
		
		define('__INAMBAPRIVATE_DEBUG__', true); # --- true/false
		define('__INAMBAPRIVATE_FORCED_RELOADED__', true); # --- true/false
		
		define('__INAMBAPRIVATE_AUTH_REQUIRED__', false); # --- true/false
		
	}else{
		
		/*
		if($_SERVER['HTTP_HOST'] === 'framework.inamba.com'){
		}
		*/
		
		define('__INAMBAPRIVATE_DEBUG__', false); # --- true/false
		define('__INAMBAPRIVATE_FORCED_RELOADED__', false); # --- true/false
		
		define('__INAMBAPRIVATE_AUTH_REQUIRED__', true); # --- true/false
		
	}
	
	/*
	
	INIT
	----------------------------------------------------------------------------------------
	
	*/
	
	require_once __INAMBAPRIVATE_PATH__.'/includes/framework/framework-functions.php';
	require_once __INAMBAPRIVATE_PATH__.'/includes/framework/framework-options.php';
	require_once __INAMBAPRIVATE_PATH__.'/includes/framework/framework-init.php';
	require_once __INAMBAPRIVATE_PATH__.'/includes/framework/framework-activation.php';
	require_once __INAMBAPRIVATE_PATH__.'/includes/framework/framework-uninstall.php';
	require_once __INAMBAPRIVATE_PATH__.'/includes/framework/framework-setup.php';
	
	register_activation_hook(__FILE__, 'inambaprivate___activate');
	
	add_action('admin_init', 'inambaprivate___activation_load');
	add_action('admin_init', 'inambaprivate___framework_options_update');
	add_action('admin_init', 'inambaprivate___framework_setup_logs');
	
	register_uninstall_hook(__FILE__, 'inambaprivate___uninstall');
	
	require_once __INAMBAPRIVATE_PATH__.'/includes/framework/framework-i18n.php';
	
	/*
	
	DEBUG
	----------------------------------------------------------------------------------------
	
	*/
	
	if(defined('__INAMBAPRIVATE_DEBUG__') && __INAMBAPRIVATE_DEBUG__ === true){
		
		require_once __INAMBAPRIVATE_PATH__.'/includes/modules/debug/init.php';
		
	}
	
	/*
	
	MODULES
	----------------------------------------------------------------------------------------
	
	*/
	
	require_once __INAMBAPRIVATE_PATH__.'/includes/modules/actions/init.php';
	require_once __INAMBAPRIVATE_PATH__.'/includes/modules/helpers/init.php';
	
	if(is_admin()){
		
		require_once __INAMBAPRIVATE_PATH__.'/includes/modules/admin/init.php';
		
	}else{
		
		require_once __INAMBAPRIVATE_PATH__.'/includes/modules/front/init.php';
		
	}
	
