Inamba Private
======

[![License](https://img.shields.io/badge/license-MIT-green)](#readme) 
[![Platform](https://img.shields.io/badge/platform-wordpress-0879b9)](#readme) 
[![Status](https://img.shields.io/badge/status-beta-yellow)](#readme)



<br>
<br>

Bookmarks
------
* Error "locked file": https://github.com/desktop/desktop/issues/5475#issuecomment-506080137
* GitHub Desktop: Open URL: https://github.com/desktop/desktop/issues/5913

Herramientas
------
* Image Compressor: https://www.iloveimg.com/compress-image
* Font Squirrel Generator: https://www.fontsquirrel.com/tools/webfont-generator
* CSS Minifier: https://www.freeformatter.com/css-minifier.html
* JS Minifier: https://jscompress.com/
* ICO Compressor: https://imagen.online-convert.com/es/convertir-a-ico
* SVG Compressor: https://jakearchibald.github.io/svgomg/
* SVG to Base64: https://base64.guru/converter/encode/image/svg
* Favicon Generator: https://realfavicongenerator.net/
* Favicon Guru: https://favicon.guru/
* WordPress Salt Keys: https://api.wordpress.org/secret-key/1.1/salt/
* ASCII CÃ³digos: https://elcodigoascii.com.ar/
* Small PDF: https://smallpdf.com/
* Gradient CSS Generator: https://cssgradient.io/
* CDR to AI (Convertio): https://convertio.co/es/cdr-ai/
* CDR to AI (Zamzar): https://www.zamzar.com/es/convert/cdr-to-ai/
* CharacterMap: http://mathew-kurian.github.io/CharacterMap/
* Unicode to HTML: https://www.online-toolz.com/tools/unicode-html-entities-convertor.php

Beta
------
* WP Robots: https://perishablepress.com/wordpress-disable-wp-robots/
* WP Robots TXT: https://wpengine.com/support/read-use-robots-txt/
* WP Robots Stackoverflow: https://stackoverflow.com/questions/28043745/wordpress-remove-robots-meta-tag-noindex
* Hackers TXT: https://stackoverflow.com/questions/15358356/what-is-the-use-of-the-hackers-txt-file
* TXT Files: http://www.textfiles.com/news/hackers.txt
* Google: https://www.google.com/.well-known/security.txt
* Security TXT: https://securitytxt.org/





<br>
<br>
<br>


###### Copyright 2011-2022 © [Inamba](https://inamba.com/).