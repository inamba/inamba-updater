<?php
	
	/*
	
	@package:			InambaPrivate
	@subpackage:		InambaPrivate_Framework_Setup
	@since:				1.0
	@updated:			2022-08-23 17:44
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	function inambaprivate___framework_setup_logs(){
		
		$folder = __INAMBAPRIVATE_PATH__.'/includes/logs';
		
		$n = "\n";
		$tab = "\t";
		
		$r = array();
		$r['result'] = false;
		$r['actions'] = array();
		
		# ------------- FOLDER (__INAMBAPRIVATE_PATH__.'includes/logs'/)
		
		if(!is_dir($folder)){
			if(mkdir($folder.'/', 0755, true) === true){
				$r['actions']['folder_created'] = true;
			}
		}
		
		# ------------- FILE (__INAMBAPRIVATE_PATH__.'includes/logs'/index.php)
		
		if(!file_exists($folder.'/index.php')){
			
			$print = '';
			$print .= '<?php '.$n;
			$print .= $tab.$n;
			
			/*
			$print .= $tab.'header("Location:../");'.$n;
			$print .= $tab.'exit;'.$n;
			*/
			
			$print .= $tab.'// SILENCE IS GOLDEN';
			
			/*
			$print .= $tab.$n;
			$print .= '?>'.$n;
			*/
			
			$fp = fopen($folder.'/index.php', 'a');
			
			fwrite($fp, $print);
			fclose($fp);
			
		}
		
		# ------------- FILE (__INAMBAPRIVATE_PATH__.'includes/logs'/.htaccess)
		
		if(!file_exists($folder.'/.htaccess')){
			
			$print = '';
			$print .= 'order deny,allow'.$n;
			$print .= 'deny from all'.$n;
			$print .= 'allow from 127.0.0.1'.$n;
			$print .= 'allow from localhost'.$n;
			
			/*
			$print .= 'allow from 179.27.200.120'.$n;
			$print .= 'allow from 193.42.143.195'.$n;
			$print .= 'allow from 217.160.0.43'.$n;
			*/
			
			$print .= 'allow from 179.27.200.120'.$n;
			$print .= 'allow from 193.42.143.195'.$n;
			$print .= 'allow from 217.160.0.43'.$n;
			$print .= ''.$n;
			
			/*
			$print .= 'Options -Indexes'.$n;
			*/
			
			$print .= '<IfModule mod_autoindex.c>'.$n;
			$print .= $tab.'Options -Indexes'.$n;
			$print .= '</IfModule>'.$n;
			
			$fp = fopen($folder.'/.htaccess', 'a');
			
			fwrite($fp, $print);
			fclose($fp);
			
			$r['actions']['file_htaccess_created'] = true;
			
		}
		
		# ------------- FILE (__INAMBAPRIVATE_PATH__.'includes/logs'/attempts.log)
		
		if(!file_exists($folder.'/attempts.log')){
			
			$print = '';
			$fp = fopen($folder.'/attempts.log', 'a');
			
			fwrite($fp, $print);
			fclose($fp);
			
			$r['actions']['file_attempts_created'] = true;
			
		}
		
		# ------------- FILE (__INAMBAPRIVATE_PATH__.'includes/logs'/errors.log)
		
		/*
		if(!file_exists($folder.'/errors.log')){
			
			$print = '';
			$fp = fopen($folder.'/errors.log', 'a');
			
			fwrite($fp, $print);
			fclose($fp);
			
			$r['actions']['file_errors_created'] = true;
			
		}
		*/
		
		
		
		
		$r['result'] = true;
		
		return $r;
		
	}
