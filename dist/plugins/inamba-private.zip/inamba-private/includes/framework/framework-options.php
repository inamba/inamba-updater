<?php
	
	/*
	
	@package:			InambaPrivate
	@subpackage:		InambaPrivate_Framework_Options
	@since:				1.0
	@updated:			2022-08-23 17:44
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	function inambaprivate___framework_options_builder(){
		
		$prefix = __INAMBAPRIVATE_SLUG__.'__';
		
		$r = array();
		
		$r['activation'] = $prefix.'activation'; # --- ONLY FOR ACTIVATION
		$r['version'] = $prefix.'version';
		$r['state'] = $prefix.'state';
		$r['updated'] = $prefix.'updated';
		
		return $r;
		
	}
	
	function inambaprivate___framework_options_update(){
		
		$prefix = __INAMBAPRIVATE_SLUG__.'__';
		
		# ------------------ VERSION
		
		if(get_option($prefix.'version') == false){
			
			add_option($prefix.'version', inambaprivate___get_plugin_version());
			
		}else{
			
			if(!function_exists('inambaprivate___get_plugin_version')){
				require_once __INAMBAPRIVATE_PATH__.'/includes/framework/framework-functions.php';
			}
			
			$current_version = inambaprivate___get_plugin_version();
			
			if($current_version > get_option($prefix.'version')){
				
				# ------------------ UPDATE > VERSION
				
				update_option($prefix.'version', inambaprivate___get_plugin_version());
				
				# ------------------ UPDATE > STATE
				
				if(get_option($prefix.'state') == false){
					add_option($prefix.'state', 'activated');
				}else{
					update_option($prefix.'state', 'activated');
				}
				
				# ------------------ UPDATE > UPDATED
				
				$wordpress_date = date_i18n('Y-m-d', strtotime('11/15-1976')).' '.current_time("H:i:s", 0);
				
				if(get_option($prefix.'updated') == false){
					add_option($prefix.'updated', $wordpress_date);
				}else{
					update_option($prefix.'updated', $wordpress_date);
				}
				
			}
			
		}
		
	}
