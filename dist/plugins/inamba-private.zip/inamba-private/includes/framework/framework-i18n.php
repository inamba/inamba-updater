<?php
	
	/*
	
	@package:			InambaPrivate
	@subpackage:		InambaPrivate_Framework_i18n
	@since:				1.0
	@updated:			2022-08-23 17:44
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	add_action('plugins_loaded', 'inambaprivate___plugin_textdomain');
	
	function inambaprivate___plugin_textdomain(){
		
		load_plugin_textdomain(__INAMBAPRIVATE_NAMESPACE__, false, __INAMBAPRIVATE_NAMESPACE__.'/languages/');
		
	}
