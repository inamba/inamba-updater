<?php
	
	/*
	
	@package:			InambaPrivate
	@subpackage:		InambaPrivate_Framework_Uninstall
	@since:				1.0
	@updated:			2022-08-23 17:44
	@comments:			
	
	https://developer.wordpress.org/plugins/plugin-basics/uninstall-methods/
	https://developer.wordpress.org/reference/functions/register_uninstall_hook/
	https://stackoverflow.com/questions/25198700/wordpress-plugin-uninstall-php
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	function inambaprivate___uninstall(){
		
		if(!current_user_can('activate_plugins')){
			return;
		}
		
		$prefix = __INAMBAPRIVATE_SLUG__.'__';
		
		$options = array();
		$options[] = $prefix.'activation';
		$options[] = $prefix.'state';
		$options[] = $prefix.'version';
		$options[] = $prefix.'updated';
		
		foreach($options as $option){
			if(get_option($option) !== false){
				delete_option($option);
			}
		}
		
	}
	
