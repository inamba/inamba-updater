<?php
	
	/*
	
	@package:			InambaPrivate
	@subpackage:		InambaPrivate_Framework_Init
	@since:				1.0
	@updated:			2022-08-23 17:44
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}

	/*
	if($_SERVER['HTTP_HOST'] === 'inamba.com'){
	}
	if($_SERVER['HTTP_HOST'] === 'hub.inamba.com'){
	}
	*/
	
	function inambaprivate___init_redirect(){
		
		if(!function_exists('inambaprivate___javascript_redirect')){
			require_once __INAMBAPRIVATE_PATH__.'/includes/framework/framework-functions.php';
		}
		
		inambaprivate___javascript_redirect(wp_login_url().'?'.__INAMBAPRIVATE_REDIRECT_SUFFIX__);
		
	}
	
	function inambaprivate___init_log_save(){
		
		$n = "\n";
		
		$r = false;
		
		$log = __INAMBAPRIVATE_PATH__.'/includes/logs'.'/attempts.log';
		
		if(file_exists($log)){
			
			$print = '';
			$print .= '============================================> LOG'.$n;
			$print .= 'DATE: '.date_i18n(get_option('date_format'), strtotime('11/15-1976')).$n; # --- https://codex.wordpress.org/Function_Reference/date_i18n
			$print .= 'TIME: '.current_time("H:i", 0).$n; # --- https://codex.wordpress.org/Function_Reference/current_time
			$print .= 'SERVER: '.$_SERVER['HTTP_HOST'].$n;
			$print .= 'SERVER_DATE: '.date('Y-m-d H:i:s').$n;
			$print .= 'IP: '.$_SERVER['REMOTE_ADDR'].$n;
			
			if(is_user_logged_in()){
				$user = wp_get_current_user();
				$print .= 'USER: '.$user->user_nicename.$n;
				$print .= 'USER_EMAIL: '.$user->user_email.$n;
				if(current_user_can('edit_posts')){
					$print .= 'USER_CAPS: edit_posts'.$n;
				}
			}
			
			if(function_exists('inambaprivate___globals')){
				$inambaprivate___globals = inambaprivate___globals();
				$print .= 'BROWSER: '.$inambaprivate___globals['browser'].$n;
				$print .= 'DEVICE: '.$inambaprivate___globals['device'].$n;
				$print .= 'OS: '.$inambaprivate___globals['os'].$n;
			}
			
			if(function_exists('inambaprivate___get_current_url')){
				$print .= 'URL: '.inambaprivate___get_current_url().$n;
			}
			
			if($_SERVER['HTTP_HOST'] != "localhost:8888"){
				if($_SERVER['REMOTE_ADDR'] != '' && $_SERVER['REMOTE_ADDR'] != '::1'){
					$inambaprivate___geolocation = inambaprivate___init_geolocation();
					$print .= 'GEOLOCATION: '.$inambaprivate___geolocation['geolocation']['city'].', '.$inambaprivate___geolocation['geolocation']['country'].$n;
				}
			}
			
			$print .= ''.$n;
			
			$fp = fopen($log, 'a');
			
			fwrite($fp, $print);
			fclose($fp);
			
			$r = true;
			
		}
		
		return $r;
		
	}
	
	function inambaprivate___init_geolocation(){
		
		$r = array();
		
		if($_SERVER['HTTP_HOST'] != "localhost:8888"){

			if($_SERVER['REMOTE_ADDR'] != '' && $_SERVER['REMOTE_ADDR'] != '::1'){

				$r['geolocation'] = array();
				$r['geolocation']['ip'] = $_SERVER['REMOTE_ADDR'];
				
				if(!class_exists('geoPlugin')){
					require_once __INAMBAPRIVATE_PATH__.'/includes/vendors/class-geoplugin.php';
				}

				$geoplugin = new geoPlugin();
				$geoplugin->locate();

				if($geoplugin->countryName != ''){

					$r['geolocation']['country'] = $geoplugin->countryName;

					$r['geolocation']['city'] = $geoplugin->city;
					$r['geolocation']['region'] = $geoplugin->region;
					$r['geolocation']['regionCode'] = $geoplugin->regionCode;
					$r['geolocation']['regionName'] = $geoplugin->regionName;
					$r['geolocation']['countryCode'] = $geoplugin->countryCode;
					$r['geolocation']['continentCode'] = $geoplugin->continentCode;
					$r['geolocation']['continentName'] = $geoplugin->continentName;
					$r['geolocation']['latitude'] = $geoplugin->latitude;
					$r['geolocation']['longitude'] = $geoplugin->longitude;
					$r['geolocation']['locationAccuracyRadius'] = $geoplugin->locationAccuracyRadius;
					$r['geolocation']['timezone'] = $geoplugin->timezone;
					$r['geolocation']['currencyCode'] = $geoplugin->currencyCode;
					$r['geolocation']['currencySymbol'] = $geoplugin->currencySymbol;

				}

				/*
				$r['geolocation']['details'] = $geoplugin;

				$r['session'] = array();

				if($_COOKIE['PHPSESSID'] != '' || $_SERVER['UNIQUE_ID'] != ''){
					$r['session']['server'] = array();
					$r['session']['server']['cookie_php_session_id'] = $_COOKIE['PHPSESSID'];
					$r['session']['server']['server_unique_id'] = $_SERVER['UNIQUE_ID']; # --- CAMBIA EN CADA SESION (SOLO EN REMOTO)
				}
				*/

			}

		}
		
		return $r;
		
	}
	