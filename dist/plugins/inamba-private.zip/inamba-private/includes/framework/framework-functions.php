<?php
	
	/*
	
	@package:			InambaPrivate
	@subpackage:		InambaPrivate_Framework_Functions
	@since:				1.0
	@updated:			2022-08-23 17:44
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	/*
	if(current_user_can('manage_options')){ # --- admin/superadmin
	}
	if(current_user_can('edit_posts')){ # --- admin/superadmin/editor/author/contributor
	}
	if(current_user_can('read')){ # --- all
	}
	if(current_user_can('activate_plugins')){ # --- activate_plugins
	}
	
	echo get_the_privacy_policy_link();
	
	if($_SERVER['HTTP_HOST'] === 'localhost:8888'){
	}
	
	if(is_admin()){
	}
	*/
	
	function inambaprivate___get_current_url(){
		
		if(isset($_SERVER['HTTPS'])){
			$r = 'https://';
		}
		else{
			$r = 'http://';
		}
		
		$r .= $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		
		return $r;
		
	}
	function inambaprivate___version_force_refresh(){
		
		$version = '';
		
		if(defined('__INAMBAPRIVATE_VERSION__')){
			$version = __INAMBAPRIVATE_VERSION__;
		}else
		if(get_option(__INAMBAPRIVATE_SLUG__.'__version') !== false){
			$version = get_option(__INAMBAPRIVATE_SLUG__.'__version');
		}else{
			$version = inambaprivate___get_plugin_version();
		}
		
		/*
		if(defined('__INAMBAPRIVATE_FORCED_RELOADED__')){
			$version = time();
		}
		*/
		
		return $version;
		
	}
	
	if(!function_exists('get_plugins')){
		
		require_once(ABSPATH.'wp-admin/includes/plugin.php');
		
	}
	
	function inambaprivate___get_plugin_version(){
		
		$r = false;
		$slug = __INAMBAPRIVATE_NAMESPACE__;
		
		$wp_plugins = get_plugins();
		foreach($wp_plugins as $wpp_path => $wpp_value){
			if($slug === $wpp_value['TextDomain']){
				$r = $wpp_value['Version'];
			}
		}
		
		return $r;
		
	}
	
	function inambaprivate___user_information(){
		
		$r = array();
		
		if(is_user_logged_in()){
			
			$user = wp_get_current_user();
			
			/*
			$user_role = $user->roles;
			$user_nicename = $user->user_nicename;
			$user_firstname = $user->first_name;
			*/
			
			if(!$user->exists()){
				return '';
			}
			else{
				
				$r['user'] = array();
				
				$r['user']['id'] = $user->ID;
				$r['user']['nicename'] = $user->user_nicename;
				$r['user']['first_name'] = $user->first_name;
				$r['user']['last_name'] = $user->last_name;
				$r['user']['display_name'] = $user->display_name;
				$r['user']['email'] = $user->user_email;
				
				$r['user']['url'] = $user->user_url;
				$r['user']['registered'] = $user->user_registered;
				
				/*
				$r['user']['pass'] = $user->user_pass;
				$r['user']['login'] = $user->user_login;
				$r['user']['activation_key'] = $user->user_activation_key;
				*/
				
				$r['user']['level'] = $user->user_level;
				$r['user']['status'] = $user->user_status;
				
				/*
				$r['details'] = $user;
				
				$user_currentinfo = get_currentuserinfo();
				if($user_currentinfo != ''){
					$r['current_info'] = $user_currentinfo;
				}
				*/
				
				$r['roles'] = $user->roles;
				
				/*
				$r['roles'] = array();
				$r['roles']['role'] = $user->roles;
				$r['roles']['allcaps'] = $user->allcaps;
				$r['roles']['cap_key'] = $user->cap_key;
				*/
				
				/*
				if($_SERVER['REMOTE_ADDR'] != '' && $_SERVER['REMOTE_ADDR'] != '::1'){
				}
				*/
				
				/*
				if(current_user_can('manage_options')){ # --- admin/superadmin
				}
				if(current_user_can('read')){ # --- all
				}
				*/
				
			}
			
		}
		
		/*
		if(!is_user_logged_in()){
		}
		if(get_option('users_can_register')){
		}
		*/
		
		return $r;
		
	}
	
	function inambaprivate___javascript_redirect($value){
		
		if($value != ''){
			echo "<script>";
			echo "var URLactual = window.location;";
			echo "top.window.location = '".$value."';";
			echo "</script>";
		}
		
	}
	
	function inambaprivate___devices_os_detect(){
		
		$browser = array("IE","OPERA","MOZILLA","NETSCAPE","FIREFOX","SAFARI","CHROME");
		$os = array("WIN","MAC","LINUX");
		
		$info['browser'] = "OTHER";
		$info['os'] = "OTHER";
		
		foreach($browser as $parent){
			$s = strpos(strtoupper($_SERVER['HTTP_USER_AGENT']), $parent);
			$f = $s + strlen($parent);
			$version = substr($_SERVER['HTTP_USER_AGENT'], $f, 15);
			$version = preg_replace('/[^0-9,.]/','',$version);
			if($s){
				$info['browser'] = $parent;
				$info['version'] = $version;
			}
		}
		
		foreach($os as $val){
			if (strpos(strtoupper($_SERVER['HTTP_USER_AGENT']),$val)!==false)
			$info['os'] = $val;
		}
		
		return $info;
		
	}
	
	function inambaprivate___globals(){
		
		$os_detect = inambaprivate___devices_os_detect();
		
		$r = array();
		
		$r["browser"] = NULL;
		$r["device"] = NULL;
		
		if(strstr($_SERVER['HTTP_USER_AGENT'],'iPhone')){
		  $r["device"] = "iPhone";
		}
		else
		if(strstr($_SERVER['HTTP_USER_AGENT'],'iPad')){
		  $r["device"] = "iPad";
		}
		else
		if(strstr($_SERVER['HTTP_USER_AGENT'],'iPod')){
		  $r["device"] = "iPod";
		}
		else
		if(strstr($_SERVER['HTTP_USER_AGENT'],'Android')){
		  $r["device"] = "Android";
		  $r["browser"] = "Android";
		}
		else
		if(strstr($_SERVER['HTTP_USER_AGENT'],'webOS')){
		  $r["device"] = "webOS";
		  $r["browser"] = "webOS";
		}
		else{
		  $r["device"] = "web";
		}
		
		if(strstr($_SERVER["HTTP_USER_AGENT"], "MSIE")){
		  $r["browser"] = "MSIE";
		}
		else
		if(strstr($_SERVER["HTTP_USER_AGENT"], "Opera")){
		  $r["browser"] = "Opera";
		}
		else
		if(strstr($_SERVER["HTTP_USER_AGENT"], "Chrome")){
		  $r["browser"] = "Chrome";
		}
		else
		if(strstr($_SERVER["HTTP_USER_AGENT"], "Firefox")){
		  $r["browser"] = "Firefox";
		}
		else
		if(strstr($_SERVER["HTTP_USER_AGENT"], "Safari")){
		  $r["browser"] = "Safari";
		}
		else
		if(strstr($_SERVER["HTTP_USER_AGENT"], "Symbian")){
		  $r["browser"] = "Symbian";
		}
		else{
		  $r["browser"] = "none";
		}
		
		if($os_detect["os"] != ""){
			
			if($os_detect["os"] == "MAC"){
				$r["os"] = "Mac";
			}
			if($os_detect["os"] == "WIN"){
				$r["os"] = "Windows";
			}
			if($os_detect["os"] == "LINUX"){
				$r["os"] = "Linux";
			}
			if($os_detect["os"] == "OTHER"){
				$r["os"] = "Other";
			}
			
		}
		
		$r["browser_version"] = $os_detect["version"];
		$r["browser_lang"] = substr($_SERVER["HTTP_ACCEPT_LANGUAGE"],0,2);
		$r["port"] = $_SERVER['SERVER_PORT'];
		$r["ip"] = $_SERVER['REMOTE_ADDR'];
		$r["uri"] = $_SERVER['REQUEST_URI'];
		$r["user_agent"] = $_SERVER['HTTP_USER_AGENT'];
		$r["isp_provider"] = gethostbyaddr($_SERVER['REMOTE_ADDR']);
		
		return $r;
		
	}
