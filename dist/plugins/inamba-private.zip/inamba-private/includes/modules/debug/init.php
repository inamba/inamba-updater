<?php
	
	/*
	
	@package:			InambaPrivate
	@subpackage:		InambaPrivate_Module_Debug
	@since:				1.0
	@updated:			2022-08-23 17:44
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	if(in_array('inamba-framework/inamba-framework.php', apply_filters('active_plugins', get_option('active_plugins')))){
	}
	
	if(in_array('inamba-pro/inamba-pro.php', apply_filters('active_plugins', get_option('active_plugins')))){
	}
	
	if(in_array('inamba-pro-private/inamba-pro-private.php', apply_filters('active_plugins', get_option('active_plugins')))){
	}
