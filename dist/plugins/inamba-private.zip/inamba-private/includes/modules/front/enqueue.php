<?php
	
	/*
	
	@package:			InambaPrivate
	@subpackage:		InambaPrivate_Module_Front
	@since:				1.0
	@updated:			2022-08-23 17:44
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	add_action('wp_head', 'inambaprivate___enqueue_public_head', 1);
	
	function inambaprivate___enqueue_public_head(){
		
		global $post;
		
		if(in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))){
			global $product;
		}
		
		$n = "\n";
		$tab = "\t";
		
	}
