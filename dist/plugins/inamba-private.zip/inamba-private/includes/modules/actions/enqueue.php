<?php
	
	/*
	
	@package:			InambaPrivate
	@subpackage:		InambaPrivate_Module_Actions
	@since:				1.0
	@updated:			2022-08-23 17:44
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	/*
	if($_SERVER['HTTP_HOST'] !== 'localhost:8888'){
	}
	*/
	
	if(is_admin()){
		
		add_action('admin_head', 'inambaprivate___enqueue_commons_head', 1);
		
	}else{
		
		add_action('wp_head', 'inambaprivate___enqueue_commons_head', 1);
		
	}
	
	function inambaprivate___enqueue_commons_head(){
		
		if(!is_user_logged_in()){
			
			inambaprivate___init_log_save(); # --- SAVELOG (FIX)
			inambaprivate___init_redirect();
			exit;
			
		}else{
			
			/*
			if(current_user_can('manage_options')){  # --- admin/superadmin
			}
			*/
			
			if(current_user_can('edit_posts')){ # --- admin/superadmin/editor/author/contributor
				
				
				
			}else{
				
				inambaprivate___init_log_save(); # --- SAVELOG (FIX)
				inambaprivate___init_redirect();
				exit;
				
			}
			
		}
		
	}
