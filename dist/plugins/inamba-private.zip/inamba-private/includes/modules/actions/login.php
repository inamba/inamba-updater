<?php
	
	/*
	
	@package:			InambaPrivate
	@subpackage:		InambaPrivate_Module_Actions
	@since:				1.0
	@updated:			2022-08-23 17:44
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	if($GLOBALS['pagenow'] === 'wp-login.php'){
		
		add_action('login_footer', 'inambaprivate___enqueue_login_head', 10, 2);
		add_action('login_enqueue_scripts', 'inambaprivate___enqueue_login_scripts', 1);
		add_action('login_enqueue_scripts', 'inambaprivate___enqueue_login_styles', 101);
		
	}
	
	function inambaprivate___enqueue_login_scripts(){
		
		$version = inambaprivate___version_force_refresh();
		
		wp_enqueue_script('inambaprivate-login', plugins_url(__INAMBAPRIVATE_NAMESPACE__.'/assets/js/login.js'), array('jquery'), $version, true);
		
	}
	
	function inambaprivate___enqueue_login_styles(){
		
		$version = inambaprivate___version_force_refresh();
		
		wp_enqueue_style('inambaprivate-login', plugins_url(__INAMBAPRIVATE_NAMESPACE__.'/assets/css/login.css'), false, $version);
		
	}
	
	function inambaprivate___enqueue_login_head(){
		
		$n = "\n";
		$tab = "\t";
		
		echo '<meta name="inambaprivate-redirect-suffix" content="'.__INAMBAPRIVATE_REDIRECT_SUFFIX__.'" />'.$n;
		echo '<meta name="inambaprivate-i18n-alert" content="'.__('You must log in to access to this page.', __INAMBAPRIVATE_NAMESPACE__).'" />'.$n;
		
		echo '<link type="text/plain" rel="robots" href="'.plugins_url(__INAMBAPRIVATE_NAMESPACE__.'/assets/modules/robots/robots.txt').' /">'.$n;
		
	}
	
