<?php
	
	/*
	
	@package:			InambaPrivate
	@subpackage:		InambaPrivate_Module_Admin
	@since:				1.0
	@updated:			2022-08-23 17:44
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	add_action('admin_enqueue_scripts', 'inambaprivate___admin_plugins');
	
	function inambaprivate___admin_plugins($hook){
		
		global $pagenow;
		
		$version = inambaprivate___version_force_refresh();
		
		if('plugins.php' == $pagenow){
			
			wp_enqueue_style('inambaprivate-admin-plugins', plugins_url(__INAMBAPRIVATE_NAMESPACE__.'/assets/css/admin-plugins.css'), false, $version);
			
		}
		
	}
