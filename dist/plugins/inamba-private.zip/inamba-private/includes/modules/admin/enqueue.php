<?php
	
	/*
	
	@package:			InambaPrivate
	@subpackage:		InambaPrivate_Module_Admin
	@since:				1.0
	@updated:			2022-08-23 17:44
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	add_action('admin_head', 'inambaprivate___enqueue_admin_head');
	
	function inambaprivate___enqueue_admin_head(){
		
		$n = "\n";
		$tab = "\t";
		
	}
