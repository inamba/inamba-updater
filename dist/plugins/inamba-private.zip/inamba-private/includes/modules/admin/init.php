<?php
	
	/*
	
	@package:			InambaPrivate
	@subpackage:		InambaPrivate_Module_Admin
	@since:				1.0
	@updated:			2022-08-23 17:44
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	/*
	require_once (dirname(__FILE__).'/enqueue.php');
	require_once (dirname(__FILE__).'/links.php');
	require_once (dirname(__FILE__).'/hooks.php');
	*/
