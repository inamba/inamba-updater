<?php
	
	/*
	
	@package:			InambaPrivate
	@subpackage:		InambaPrivate_Module_Admin
	@since:				1.0
	@updated:			2022-08-23 17:44
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	/*
	add_filter("plugin_action_links", 'inambaprivate___links_support', 10, 4);
	*/
	
	add_filter('plugin_row_meta', 'inambaprivate___links_row_meta', 10, 2);
	
    function inambaprivate___links_support($links, $file){
        
		$plugin_file = __INAMBAPRIVATE_NAMESPACE__.'/'.__INAMBAPRIVATE_NAMESPACE__.'.php';
        
		if($file == $plugin_file){
			
			/*
			$settings_link = '<a href="'.admin_url('admin.php?page='.__INAMBAPRIVATE_SLUG__).'">'.__('Support', __INAMBAPRIVATE_NAMESPACE__).'</a>';
            array_unshift($links, $settings_link);
			*/
			
			$settings_link = '<a href="mailto:support@inamba.com?subject='.esc_html__('Support from', __INAMBAPRIVATE_NAMESPACE__).' '.get_bloginfo('name', '').' ('.get_bloginfo("url", "").'/)">'.esc_html__('Support', __INAMBAPRIVATE_NAMESPACE__).'</a>';
            array_unshift($links, $settings_link);
			
        }
		
        return $links;
		
    }
	
	function inambaprivate___links_row_meta($links, $file){
		
		$plugin_file = __INAMBAPRIVATE_NAMESPACE__.'/'.__INAMBAPRIVATE_NAMESPACE__.'.php';
		
		if($file == $plugin_file){
			
			/*
			$links[] = '<a href="mailto:support@inamba.com?subject='.esc_html__('Support from', __INAMBAPRIVATE_NAMESPACE__).' '.get_bloginfo('name', '').' ('.get_bloginfo("url", "").'/)">'.esc_html__('Support', __INAMBAPRIVATE_NAMESPACE__).'</a>';
			*/
			
			$headers_instance = inambaprivate___headers_builder(__INAMBAPRIVATE_PATH__.'inamba-private.php');
			
			/*
			$links[] = '<a href="'.esc_url($headers_instance['@github']).'" rel="nofollow noarchive noreferrer" target="_blank">'.esc_html__('GitHub', __INAMBAPRIVATE_NAMESPACE__).'</a>';
			*/
			
			$links[] = '<a href="'.esc_url($headers_instance['@support']).'" rel="nofollow noarchive noreferrer" target="_blank">'.esc_html__('Support', __INAMBAPRIVATE_NAMESPACE__).'</a>';
			
		}
		
		return $links;
		
	}
