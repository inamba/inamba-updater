<?php
	
	/*
	
	@package:			InambaPrivate
	@subpackage:		InambaPrivate_Module_Helpers
	@since:				1.0
	@updated:			2022-08-23 17:44
	@comments:			
	
	https://developer.wordpress.org/reference/functions/get_file_data/
	https://developer.wordpress.org/plugins/plugin-basics/header-requirements/
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	function inambaprivate___headers_builder($file){
		
		$r = false;
		
		if($file){
			
			$r = array();
			$filedata = get_file_data($file, inambaprivate___extra_headers());
			
			foreach($filedata as $header_name => $header_value){
				if(isSet($header_value) && $header_value != ''){
					
					$r[$header_name] = $header_value;
					
				}
			}
			
		}
		
		return $r;
		
	}
	
	function inambaprivate___extra_headers(){
		
		/*
		$headers['name'] = 'Plugin Name';
		$headers['version'] = 'Version';
		$headers['stable_tag'] = 'Stable tag';
		$headers['requires_php'] = 'Requires PHP';
		$headers['requires_at_least'] = 'Requires at least';
		$headers['description'] = 'Description';
		$headers['author'] = 'Author';
		$headers['author_uri'] = 'Author URI';
		$headers['tested_up_to'] = 'Tested up to';
		
		$headers['Page Name'] = 'Page Name';
		$headers['Preview Image'] = 'Preview Image';
		$headers['Template File'] = 'Template File';
		*/
		
		$headers['@package'] = '@package';
		$headers['@subpackage'] = '@subpackage';
		$headers['@copyright'] = '@copyright';
		$headers['@support'] = '@support';
		$headers['@since'] = '@since';
		$headers['@updated'] = '@updated';
		$headers['@email'] = '@email';
		
		$headers['@comments'] = '@comments';
		
		$headers['@github'] = '@github';
		
		return $headers;
		
	}
	
	function inambaprivate___plugin_info(){
		
		add_filter('extra_plugin_headers', 'inambaprivate___extra_headers', 99, 1);
		$plugin_data = get_plugin_data(__INAMBAPRIVATE_PATH__.__INAMBAPRIVATE_NAMESPACE__.'.php');
		remove_filter('extra_plugin_headers', 'inambaprivate___extra_headers', 99, 1);
		
		return $plugin_data;
		
	}
