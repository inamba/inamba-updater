(function($){
    
	'use strict';
	
	function inambaprivate__get_meta(metaName){
		const metas = document.getElementsByTagName('meta');
		for(let i = 0; i < metas.length; i++){
			if(metas[i].getAttribute('name') === metaName){
				return metas[i].getAttribute('content');
			}
		}
		return '';
	}
	
	var inambaprivate__login_redirect_suffix = inambaprivate__get_meta('inambaprivate-redirect-suffix');
	var inambaprivate__login_i18n_alert = inambaprivate__get_meta('inambaprivate-i18n-alert');
	
	/*
	var window_width = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
	var window_height = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
	*/
	
	var window_location = window.location;
	var window_location_host = window.location.host;
	var window_location_uri = window.location.pathname + window.location.search;
	
	/*
	var window_location_protocol = window.location.protocol;
	var window_location_domain = window.location.hostname;
	var window_browser_useragent = window.navigator.userAgent;	
	*/
	
	/*
	window.addEventListener("load", function(){
	});
	
	$(window).load(function(){
	});
	*/
	
	function inambaprivate_login_init(){
		
		console.log("Inamba Private > URL: " + window_location);
		console.log("Inamba Private > Host: " + window_location_host);
		
		if(window_location_uri == '/wp-login.php?' + inambaprivate__login_redirect_suffix){
			
			console.log("Inamba Private is running!");
			
			/*
			alert("Current URL: " + window_location);
			alert("URI: " + window_location_uri);
			*/
			
		}
		
	}
	
	$(document).ready(function(){
		
		inambaprivate_login_init();
		
    });	
	
})(jQuery);