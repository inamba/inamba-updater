"use strict";

jQuery(document).ready(function(){
	history.pushState(null, null, woo_vou_success.woo_vou_success_admin_url);
});