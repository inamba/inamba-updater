jQuery(document).ready( function($){
	if( $('#wcfm_products_manage_form').length ) {
		$('#is_downloadable').attr( 'checked', true );
	}
});