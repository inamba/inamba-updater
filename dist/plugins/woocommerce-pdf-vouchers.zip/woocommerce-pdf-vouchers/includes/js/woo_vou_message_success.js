"use strict";

jQuery(document).ready(function(){
	history.pushState(null, null, woo_vou_message_success.woo_vou_message_success_new_url);
});