<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/job-employment-type" only-nested=true recommended-for=[ "yoast/job-posting" ] }}
{{job-employment-type }}
