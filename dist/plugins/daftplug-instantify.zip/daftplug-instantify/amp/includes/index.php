<?php 

// Silence is golden ;)

?>