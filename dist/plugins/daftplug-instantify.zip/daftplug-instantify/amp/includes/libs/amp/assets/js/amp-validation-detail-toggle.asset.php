<?php return array('dependencies' => array('wp-dom-ready', 'wp-i18n'), 'version' => '58c2ec5e49d1bbda934e');
