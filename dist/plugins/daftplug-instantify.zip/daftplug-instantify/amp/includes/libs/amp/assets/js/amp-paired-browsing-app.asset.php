<?php return array('dependencies' => array('wp-url'), 'version' => '8616ab9c9e905c1d28bf');
