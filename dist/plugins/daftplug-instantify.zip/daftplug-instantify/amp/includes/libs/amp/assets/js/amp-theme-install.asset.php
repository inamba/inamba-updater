<?php return array('dependencies' => array('wp-dom-ready', 'wp-i18n'), 'version' => 'a7c8840a45b19747f73e');
