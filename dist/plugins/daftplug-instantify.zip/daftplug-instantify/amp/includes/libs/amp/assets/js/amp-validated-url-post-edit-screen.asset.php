<?php return array('dependencies' => array('wp-dom-ready', 'wp-i18n'), 'version' => '33959fa6e5cb2a50a66d');
