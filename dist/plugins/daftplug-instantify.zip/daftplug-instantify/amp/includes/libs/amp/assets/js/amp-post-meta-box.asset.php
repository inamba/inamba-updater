<?php return array('dependencies' => array(), 'version' => 'b540aa3dd4a1b8f5694d');
