<?php return array('dependencies' => array(), 'version' => 'f77871ff7694fffea381');
