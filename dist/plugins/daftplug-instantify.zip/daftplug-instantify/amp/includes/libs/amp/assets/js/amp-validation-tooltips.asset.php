<?php return array('dependencies' => array('wp-dom-ready', 'wp-pointer'), 'version' => 'ae3f02c83a308375aa51');
