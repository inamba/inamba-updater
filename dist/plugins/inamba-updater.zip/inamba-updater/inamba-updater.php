<?php
	
	/*
	
	Plugin Name: 				Inamba Updater
	Description: 				Manage all updates on your WordPress site including plugins, themes and translations. Stay in the know with several optional e-mail notifications and logs. Developed by Inamba.
	Version: 					1.0.1
	Stable tag: 				1.0
	Author: 					Inamba
	Author URI: 				https://inamba.com/
	License: 					MIT
	License URI: 				https://opensource.org/licenses/MIT
	Text Domain: 				inamba-updater
	Domain Path: 				/languages/
	
	@package:					Inamba\Updater
	@copyright:					2023 © Inamba
	@link:						https://market.inamba.com/
	@since:						1.0
	@updated:					2022-04-25 00:00
	@email:						market@inamba.com
	@comments:			
	
	@github:					https://github.com/inamba/updater
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	define('__INAMBAPROUPDATER__', true);
	define('__INAMBAPROUPDATER_PATH__', plugin_dir_path(__FILE__));
	define('__INAMBAPROUPDATER_URL__', plugin_dir_url(__FILE__));
	define('__INAMBAPROUPDATER_NAME__', 'Inamba Updater');
	define('__INAMBAPROUPDATER_NAMESPACE__', 'inamba-updater');
	define('__INAMBAPROUPDATER_SLUG__', 'inambaupdater');
	define('__INAMBAPROUPDATER_ADMIN_PATH__', 'admin.php?page='.__INAMBAPROUPDATER_SLUG__);
	define('__INAMBAPROUPDATER_FOLDER__', plugin_basename(dirname(__FILE__)));
	define('__INAMBAPROUPDATER_FILENAME__', plugin_basename(__FILE__));
	
	
	
	

