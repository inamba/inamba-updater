<?php
	
	/*
	
	Plugin Name: 				Inamba Updater
	Description: 				Manage all updates on your WordPress site including plugins, themes and translations. Stay in the know with several optional e-mail notifications and logs. Developed by Inamba.
	Version: 					1.3.0
	Stable tag: 				1.0
	Author: 					Inamba
	Author URI: 				https://inamba.com/
	License: 					MIT
	License URI: 				https://opensource.org/licenses/MIT
	Text Domain: 				inamba-updater
	Domain Path: 				/languages/
	Requires at least: 			6.0
	Tested up to: 				6.1.1
	Requires PHP: 				7.3
	
	@package:					Inamba\Updater
	@copyright:					2023 © Inamba
	@link:						https://market.inamba.com/
	@since:						1.0
	@updated:					2022-00-00 00:00
	@email:						market@inamba.com
	@comments:			
	
	@github:					https://github.com/inamba/updater
	@github_author:				https://github.com/inamba
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	define('__INAMBAUPDATER__', true);
	define('__INAMBAUPDATER_PATH__', plugin_dir_path(__FILE__));
	define('__INAMBAUPDATER_URL__', plugin_dir_url(__FILE__));
	define('__INAMBAUPDATER_NAME__', 'Inamba Updater');
	define('__INAMBAUPDATER_NAMESPACE__', 'inamba-updater');
	define('__INAMBAUPDATER_SLUG__', 'inambaupdater');
	define('__INAMBAUPDATER_ADMIN_PATH__', 'admin.php?page='.__INAMBAUPDATER_SLUG__);
	define('__INAMBAUPDATER_FOLDER__', plugin_basename(dirname(__FILE__)));
	define('__INAMBAUPDATER_FILENAME__', plugin_basename(__FILE__));
	
	if(get_option(__INAMBAUPDATER_SLUG__.'__version') !== false){
		define('__INAMBAUPDATER_VERSION__', get_option(__INAMBAUPDATER_SLUG__.'__version'));
	}
	
	if($_SERVER['HTTP_HOST'] !== "lidiasanchez.com"){
		define('__INAMBAUPDATER_DEBUG__', true); # --- true/false
		define('__INAMBAUPDATER_FORCED_RELOADED__', true); # --- true/false
	}else{
		define('__INAMBAUPDATER_DEBUG__', false); # --- true/false
		define('__INAMBAUPDATER_FORCED_RELOADED__', false); # --- true/false
	}
	
	/*
	
	FRAMEWORK
	------------------------------------------------------------------------------------------------- 
	
	*/
	
	require_once __INAMBAUPDATER_PATH__.'/includes/framework/framework-functions.php';
	require_once __INAMBAUPDATER_PATH__.'/includes/framework/framework-i18n.php';
	require_once __INAMBAUPDATER_PATH__.'/includes/framework/framework-options.php';
	require_once __INAMBAUPDATER_PATH__.'/includes/framework/framework-activation.php';
	require_once __INAMBAUPDATER_PATH__.'/includes/framework/framework-deactivation.php';
	require_once __INAMBAUPDATER_PATH__.'/includes/framework/framework-uninstall.php';
	
	register_activation_hook(__FILE__, 'inambaupdater___activate');
	add_action('admin_init', 'inambaupdater___activation_load');
	add_action('admin_init', 'inambaupdater___framework_options_update');
	register_deactivation_hook(__FILE__, 'inambaupdater___deactivate');
	register_uninstall_hook(__FILE__, 'inambaupdater___uninstall');
	
	/*
	
	DEPENDENCIES
	------------------------------------------------------------------------------------------------- 
	
	*/
	
	if(in_array('inamba-pro/inamba-pro.php', apply_filters('active_plugins', get_option('active_plugins')))){
	}
	if(in_array('inamba-pro-debug/inamba-pro-debug.php', apply_filters('active_plugins', get_option('active_plugins')))){
	}
	
	/*
	
	ENVIRONMENTS
	------------------------------------------------------------------------------------------------- 
	
	*/
	
	if(defined('WP_ENVIRONMENT_TYPE') && WP_ENVIRONMENT_TYPE !== ''){
		
		/*
		if(WP_ENVIRONMENT_TYPE === 'local'){
		}else
		if(WP_ENVIRONMENT_TYPE === 'development'){
		}else{
		}
		*/
		
		define('__INAMBAUPDATER_ENVIRONMENT__', WP_ENVIRONMENT_TYPE);
		
	}
	
	/*
	
	DEBUG
	------------------------------------------------------------------------------------------------- 
	
	*/
	
	if(defined('__INAMBAUPDATER_DEBUG__') && __INAMBAUPDATER_DEBUG__ === true){
	}
	
	/*
	
	MODULES
	------------------------------------------------------------------------------------------------- 
	
	*/
	
	require_once __INAMBAUPDATER_PATH__.'/includes/modules/helpers/init.php';
	
	if(is_admin()){
	}
	
	
	
	
	
	

