<?php
	
	/*
	
	Plugin Name: 				Inamba Updater
	Description: 				Manage all updates on your WordPress site including plugins, themes and translations. Stay in the know with several optional e-mail notifications and logs. Developed by Inamba.
	Version: 					1.0.2
	Stable tag: 				1.0
	Author: 					Inamba
	Author URI: 				https://inamba.com/
	License: 					MIT
	License URI: 				https://opensource.org/licenses/MIT
	Text Domain: 				inamba-updater
	Domain Path: 				/languages/
	
	@package:					Inamba\Updater
	@copyright:					2023 © Inamba
	@link:						https://market.inamba.com/
	@since:						1.0
	@updated:					2022-00-00 00:00
	@email:						market@inamba.com
	@comments:			
	
	@github:					https://github.com/inamba/updater
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	define('__INAMBAUPDATER__', true);
	define('__INAMBAUPDATER_PATH__', plugin_dir_path(__FILE__));
	define('__INAMBAUPDATER_URL__', plugin_dir_url(__FILE__));
	define('__INAMBAUPDATER_NAME__', 'Inamba Updater');
	define('__INAMBAUPDATER_NAMESPACE__', 'inamba-updater');
	define('__INAMBAUPDATER_SLUG__', 'inambaupdater');
	define('__INAMBAUPDATER_ADMIN_PATH__', 'admin.php?page='.__INAMBAUPDATER_SLUG__);
	define('__INAMBAUPDATER_FOLDER__', plugin_basename(dirname(__FILE__)));
	define('__INAMBAUPDATER_FILENAME__', plugin_basename(__FILE__));
	
	/*
	
	FRAMEWORK
	------------------------------------------------------------------------------------------------- 
	
	*/
	
	require_once __INAMBAUPDATER_PATH__.'/includes/framework/framework-i18n.php';
	
	

