<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Framework\Options
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	function inambaupdater___framework_options_builder(){
		
		$prefix = __INAMBAUPDATER_SLUG__.'__';
		
		$r = array();
		
		$r['activation'] = $prefix.'activation'; # --- ONLY FOR ACTIVATION
		$r['version'] = $prefix.'version';
		$r['state'] = $prefix.'state';
		$r['token'] = $prefix.'token'; # --- API
		$r['settings'] = $prefix.'settings';
		$r['updated'] = $prefix.'updated';
		$r['options'] = $prefix.'options';
		$r['deactivation'] = $prefix.'deactivation'; # --- ONLY FOR DEACTIVATION
		$r['deactivation_date'] = $prefix.'deactivation_date'; # --- ONLY FOR DEACTIVATION
		
		$r['tgmpa'] = $prefix.'tgmpa'; # --- TGMPA
		
		$r['integrations'] = $prefix.'integrations';
		
		return $r;
		
	}
	
	function inambaupdater___framework_options_update(){
		
		$prefix = __INAMBAUPDATER_SLUG__.'__';
		
		# ------------------ VERSION
		
		if(get_option($prefix.'version') == false){
			
			add_option($prefix.'version', inambaupdater___get_plugin_version());
			
		}else{
			
			if(!function_exists('inambaupdater___get_plugin_version')){
				require_once __INAMBAUPDATER_PATH__.'/includes/framework/framework-functions.php';
			}
			
			$current_version = inambaupdater___get_plugin_version();
			
			if($current_version > get_option($prefix.'version')){
				
				# ------------------ UPDATE > version
				
				update_option($prefix.'version', inambaupdater___get_plugin_version());
				
				# ------------------ UPDATE > updated
				
				/*
				$wordpress_date = date_i18n('Y-m-d', strtotime('11/15-1976')).' '.current_time("H:i:s", 0);
				$wordpress_date = date_i18n('D j M Y', strtotime('11/15-1976')).' '.current_time("H:i:s", 0);
				*/
				
				$wordpress_date = date_i18n('Y-m-d', strtotime('11/15-1976')).' '.current_time("H:i:s", 0);

				if(get_option($prefix.'updated') == false){
					add_option($prefix.'updated', $wordpress_date);
				}else{
					update_option($prefix.'updated', $wordpress_date);
				}
				
				# ------------------ UPDATE > tgmpa
				
				if(defined('WP_ENVIRONMENT_TYPE') && WP_ENVIRONMENT_TYPE !== 'production'){
					
					$tgmpa_status = 'true'; # --- true
					
				}else{
					
					if(in_array('inamba-pro-debug/inamba-pro-debug.php', apply_filters('active_plugins', get_option('active_plugins')))){
						$tgmpa_status = 'true'; # --- false
					}else{
						$tgmpa_status = 'false'; # --- false
					}
					
					/*
					$tgmpa_status = 'false'; # --- false
					*/
					
				}
				
				if(get_option($prefix.'tgmpa') == false){
					add_option($prefix.'tgmpa', $tgmpa_status);
				}else{
					update_option($prefix.'tgmpa', $tgmpa_status);
				}
				
				# ------------------ UPDATE > integrations
				
				unset($integrations_framework_builder);
				
				$integrations_framework_builder = array();
				$integrations_framework_builder["version"] = __INAMBAUPDATER_INTEGRATIONS_VERSION__;
				$integrations_framework_builder["updated"] = date_i18n('Y-m-d', strtotime('11/15-1976')).' '.current_time("H:i:s", 0);
				$integrations_framework_builder["host"] = $_SERVER['HTTP_HOST'];
				$integrations_framework_builder["wordpress_url"] = get_bloginfo('url', '');
				$integrations_framework_builder["wordpress_version"] = get_bloginfo('version', '');
				$integrations_framework_builder["wordpress_locale"] = get_locale();
				
				$integrations_framework_serialized = serialize($integrations_framework_builder);
				
				if(get_option($prefix.'integrations') == false){
					add_option($prefix.'integrations', $integrations_framework_serialized);
				}else{
					update_option($prefix.'integrations', $integrations_framework_serialized);
				}
				
			}
			
		}
		
	}
