<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Framework\Functions
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	/*
	if(current_user_can('manage_options')){ # --- admin/superadmin
	}
	if(current_user_can('edit_posts')){ # --- admin/superadmin/editor/author/contributor
	}
	if(current_user_can('read')){ # --- all
	}
	if(current_user_can('activate_plugins')){ # --- activate_plugins
	}
	
	echo get_the_privacy_policy_link();
	
	if($_SERVER['HTTP_HOST'] === 'lidiasanchez.com'){
	}
	if($_SERVER['HTTP_HOST'] === 'dev.lidiasanchez.com'){
	}
	if($_SERVER['HTTP_HOST'] === 'localhost:8888'){
	}
	
	if(is_admin()){
	}
	*/
	
	/*
	$show_address = false;

	if(is_front_page() && is_home()){
		$show_address = true; # --- DEFAULT HOMEPAGE
	}
	else
	if(is_front_page()){
		$show_address = true; # --- STATIC HOMEPAGE
	}
	else
	if(is_home()){
		$show_address = true; # --- BLOGPAGE
	}
	else{
		$show_address = true; # --- EVERYTHING ELSE
	}
	*/
	
	function inambapro___options(){
		
		$slug = __INAMBAUPDATER_SLUG__;
		
		$r = array();
		$r[] = $slug.'__activation';
		$r[] = $slug.'__install_date';
		$r[] = $slug.'__version';
		$r[] = $slug.'__version_update';
		$r[] = $slug.'__license';
		$r[] = $slug.'__settings';
		
		return $r;
		
	}
	
	function inambapro___updated_time_resolve(){
		
		$r = false;
		
		/*
		if(__INAMBAUPDATER_UPDATE__){
			
			$r = array();
			
			$explode_updated = explode(' ', __INAMBAUPDATER_UPDATE__);
			
			$explode_date = explode('-', $explode_updated[0]);
			$explode_time = explode(':', $explode_updated[1]);
			
			$r['date'] = $explode_date[2].'/'.$explode_date[1].'/'.$explode_date[0];
			$r['time'] = $explode_time[0].':'.$explode_time[1];
			
		}
		*/
		
		if(function_exists('inambapro___headers_builder')){
			
			$r = array();
			
			$headers_instance = inambapro___headers_builder(__INAMBAUPDATER_PATH__.__INAMBAUPDATER_NAMESPACE__.'.php');
			$updated = $headers_instance['@updated'];
			
			$explode_updated = explode(' ', $updated);
			
			$explode_date = explode('-', $explode_updated[0]);
			$explode_time = explode(':', $explode_updated[1]);
			
			$r['date'] = $explode_date[2].'/'.$explode_date[1].'/'.$explode_date[0];
			$r['time'] = $explode_time[0].':'.$explode_time[1];
			
			$r['updated'] = $updated;
			
		}
		
		return $r;
		
	}
	
	function inambapro___version_force_refresh(){
		
		/*
		$version = get_option(__INAMBAUPDATER_SLUG__.'__version');
		if(__INAMBAUPDATER_FORCED_RELOADED__ != false){
			$version = time();
		}
		*/
		
		$version = '';
		
		if(defined('__INAMBAUPDATER_VERSION__')){
			$version = __INAMBAUPDATER_VERSION__;
		}else
		if(get_option(__INAMBAUPDATER_SLUG__.'__version') !== false){
			$version = get_option(__INAMBAUPDATER_SLUG__.'__version');
		}else{
			$version = inambapro___get_plugin_version();
		}
		
		# ------------------ FORCE
		
		if(defined('__INAMBAUPDATER_FORCED_RELOADED__')){
			$version = time();
		}
		
		return $version;
		
	}
	
	if(!function_exists('get_plugins')){
		require_once(ABSPATH.'wp-admin/includes/plugin.php');
	}
	
	function inambapro___get_plugin_version(){
		
		$r = false;
		$slug = __INAMBAUPDATER_NAMESPACE__;
		
		$wp_plugins = get_plugins();
		foreach($wp_plugins as $wpp_path => $wpp_value){
			if($slug === $wpp_value['TextDomain']){
				$r = $wpp_value['Version'];
			}
		}
		
		return $r;
		
	}
	
	function inambapro___get_current_url(){
		
		/*
		$current_url = inambapro___get_current_url();
		*/
		
		if(isset($_SERVER['HTTPS'])){
			$r = 'https://';
		}
		else{
			$r = 'http://';
		}
		
		$r .= $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		
		return $r;
		
	}
	
