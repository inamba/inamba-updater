<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Framework\i18n
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	add_action('plugins_loaded', 'inambaupdater___load_textdomain');
	
	function inambaupdater___load_textdomain(){
		load_plugin_textdomain(__INAMBAUPDATER_NAMESPACE__, false, __INAMBAUPDATER_NAMESPACE__.'/languages/');
	}
