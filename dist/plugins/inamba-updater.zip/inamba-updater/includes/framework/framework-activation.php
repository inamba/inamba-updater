<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Framework\Activation
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	https://codex.wordpress.org/Function_Reference/register_activation_hook
	https://wordpress.stackexchange.com/questions/25910/uninstall-activate-deactivate-a-plugin-typical-features-how-to/25979#25979
	https://codex.wordpress.org/Plugin_API/Action_Reference/plugins_loaded
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	function inambaupdater___activate(){
		
		if(!current_user_can('activate_plugins')){
			return;
		}
		
		$plugin = isset($_REQUEST['plugin']) ? $_REQUEST['plugin'] : '';
		check_admin_referer("activate-plugin_{$plugin}");
		
		$prefix = __INAMBAUPDATER_SLUG__.'__';
		
		add_option($prefix.'activation', '1');
		
	}
	
	function inambaupdater___activation_load(){
		
		$prefix = __INAMBAUPDATER_SLUG__.'__';
		
		if(is_admin() && get_option($prefix.'activation') == '1'){
			
			delete_option($prefix.'activation');
			
			# --------------- DEACTIVATION

			if(get_option($prefix.'deactivation') == '1'){
				update_option($prefix.'deactivation', '0');
			}
			
			# --------------- STATE

			if(get_option($prefix.'state') == false){
				add_option($prefix.'state', 'activated');
			}

			# --------------- TOKEN
			
			if(get_option($prefix.'token') == false){
				add_option($prefix.'token', inambaupdater___build_token());
			}
			
			# --------------- OPTIONS

			if(get_option($prefix.'options') == false){
				add_option($prefix.'options', serialize(array()));
			}

			# --------------- INFO
			
			$user = wp_get_current_user();
			
			$info = array();
			$info['installed_date'] = date_i18n('Y-m-d', strtotime('11/15-1976')).' '.current_time("H:i:s", 0);
			$info['installer_user_email'] = $user->user_email;
			$info['installer_user_nicename'] = $user->user_nicename;
			$info['site_admin_email'] = get_bloginfo('admin_email', '');
			$info['site_url'] = get_bloginfo('url', '');
			$info['site_wordpress_url'] = get_bloginfo('wpurl', '');
			$info['site_version'] = get_bloginfo('version', '');
			
			$build_info = serialize($info);
			
			if(get_option($prefix.'settings') == false){
				add_option($prefix.'settings', $build_info);
			}
			
			unset($user);
			unset($info);
			unset($build_info);
			
			# --------------- TGMPA
			
			if(defined('WP_ENVIRONMENT_TYPE') && WP_ENVIRONMENT_TYPE !== 'production'){
				$tgmpa_status = 'true'; # --- true
			}else{
				$tgmpa_status = 'false'; # --- false
			}
			
			if(get_option($prefix.'tgmpa') == false){
				add_option($prefix.'tgmpa', $tgmpa_status);
			}
			
		}
		
	}
