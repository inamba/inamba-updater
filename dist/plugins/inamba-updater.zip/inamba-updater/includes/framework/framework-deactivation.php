<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Framework\Deactivation
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	https://codex.wordpress.org/Function_Reference/register_deactivation_hook
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	function inambaupdater___deactivate(){
		
		if(!current_user_can('activate_plugins')){
			return;
		}
		
		$prefix = __INAMBAUPDATER_SLUG__.'__';
		
		if(get_option($prefix.'deactivation') !== false){
			
			update_option($prefix.'deactivation', '1');
			update_option($prefix.'deactivation_date', date_i18n('Y-m-d', strtotime('11/15-1976')).' '.current_time("H:i:s", 0));
			
		}else{
			
			add_option($prefix.'deactivation', '1');
			add_option($prefix.'deactivation_date', date_i18n('Y-m-d', strtotime('11/15-1976')).' '.current_time("H:i:s", 0));
			
		}
		
	}
