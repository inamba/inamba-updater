<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Framework\Uninstall
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	https://developer.wordpress.org/plugins/plugin-basics/uninstall-methods/
	https://developer.wordpress.org/reference/functions/register_uninstall_hook/
	https://stackoverflow.com/questions/25198700/wordpress-plugin-uninstall-php
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	function inambaupdater___uninstall(){
		
		if(!current_user_can('activate_plugins')){
			return;
		}
		
		$prefix = __INAMBAUPDATER_SLUG__.'__';
		
		$options = array();
		$options[] = $prefix.'activation';
		$options[] = $prefix.'deactivation';
		$options[] = $prefix.'deactivation_date';
		$options[] = $prefix.'state';
		$options[] = $prefix.'version';
		$options[] = $prefix.'token'; # --- API
		$options[] = $prefix.'settings';
		$options[] = $prefix.'updated';
		$options[] = $prefix.'options';
		$options[] = $prefix.'tgmpa'; # --- TGMPA
		
		$options[] = $prefix.'integrations';
		
		foreach($options as $option){
			if(get_option($option) !== false){
				delete_option($option);
			}
		}
		
	}
	
