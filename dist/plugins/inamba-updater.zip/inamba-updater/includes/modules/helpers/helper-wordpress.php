<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Module\Helpers
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	/*
	if(function_exists('inambaupdater___wp_globals')){
		$inambaupdater___wp_globals = inambaupdater___wp_globals();
	}
	*/
	
	function inambaupdater___wp_globals(){
		
		$i = 0;
		$r = array();
		
		$r['wordpress'] = array();
		
		$r['wordpress']['url'] = get_bloginfo('url', '');
		$r['wordpress']['wpurl'] = get_bloginfo('wpurl', '');
		$r['wordpress']['admin_url'] = esc_url(admin_url());
		
		if(get_option('users_can_register')){
			$r['wordpress']['registration_url'] = wp_registration_url();
		}
		
		$r['wordpress']['lostpassword_url'] = wp_lostpassword_url();
		$r['wordpress']['login_url'] = wp_login_url();
		
		if(get_option('users_can_register')){
			$r['wordpress']['users_can_register'] = 1;
		}
		else{
			$r['wordpress']['users_can_register'] = 0;
		}
		
		if(in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))){
			
			global $woocommerce;
			
			$r['woocommerce'] = array();
			
			$r['woocommerce']['account'] = wc_get_page_permalink('myaccount');
			$r['woocommerce']['shop'] = wc_get_page_permalink('shop');
			$r['woocommerce']['cart'] = wc_get_page_permalink('cart');
			$r['woocommerce']['checkout'] = wc_get_page_permalink('checkout');
			$r['woocommerce']['terms'] = wc_get_page_permalink('terms');
			
			if(!is_admin()){
				
				$r['woocommerce']['cart_total'] = $woocommerce->cart->get_cart_total();
				$r['woocommerce']['cart_count'] = $woocommerce->cart->cart_contents_count;
				
			}
			
		}
		
		if(get_the_privacy_policy_link() != ''){
			
			$r['privacy'] = array();
			
			$r['privacy']['id'] = (int)get_option('wp_page_for_privacy_policy');
			$r['privacy']['url'] = esc_url(get_privacy_policy_url());
			$r['privacy']['title'] = ($r['privacy']['id']) ? get_the_title($r['privacy']['id']) : '';
			$r['privacy']['link'] = get_the_privacy_policy_link();
			
			unset($r['privacy']['id']);
			unset($r['privacy']['link']);
			
		}
		
		unset($options);
		$options = array('current_theme', 'timezone_string', 'page_for_posts', 'page_on_front', 'site_icon', 'WPLANG', 'show_on_front', 'template', 'stylesheet', 'default_role', 'date_format', 'time_format', 'show_avatars', 'wp_page_for_privacy_policy');
		$options_globals = $options;
		
		if(in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))){
			unset($options);
			$options = array('woocommerce_store_address', 'woocommerce_store_address_2', 'woocommerce_store_city', 'woocommerce_store_postcode', 'woocommerce_email_from_name', 'woocommerce_email_from_address', 'woocommerce_stock_email_recipient', 'woocommerce_version');
			$options_woocommerce = $options;
		}
		
		$build_options = array_merge($options_globals, $options_woocommerce);
		
		foreach($build_options as $option){
			
			if(get_option($option) != ''){
				
				$builded[$option] = get_option($option);
				
			}
			
		}
		
		$r['wordpress']['blog'] = esc_url(get_permalink(get_option('page_for_posts')));
		$r['wordpress']['front'] = esc_url(get_permalink(get_option('page_on_front')));
		
		$r['options'] = $builded;
		
		return $r;
		
	}
	
