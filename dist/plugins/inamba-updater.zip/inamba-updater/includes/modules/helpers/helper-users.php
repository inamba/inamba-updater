<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Module\Helpers
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	function inambaupdater___user_information(){
		
		$r = array();
		
		if(is_user_logged_in()){
			
			$user = wp_get_current_user();
			
			/*
			$user_role = $user->roles;
			$user_nicename = $user->user_nicename;
			$user_firstname = $user->first_name;
			*/
			
			if(!$user->exists()){
				return '';
			}
			else{
				
				$r['user'] = array();
				
				$r['user']['id'] = $user->ID;
				$r['user']['nicename'] = $user->user_nicename;
				$r['user']['first_name'] = $user->first_name;
				$r['user']['last_name'] = $user->last_name;
				$r['user']['display_name'] = $user->display_name;
				$r['user']['email'] = $user->user_email;
				
				$r['user']['url'] = $user->user_url;
				$r['user']['registered'] = $user->user_registered;
				
				/*
				$r['user']['pass'] = $user->user_pass;
				$r['user']['login'] = $user->user_login;
				$r['user']['activation_key'] = $user->user_activation_key;
				*/
				
				$r['user']['level'] = $user->user_level;
				$r['user']['status'] = $user->user_status;
				
				/*
				$r['details'] = $user;
				
				$user_currentinfo = get_currentuserinfo();
				if($user_currentinfo != ''){
					$r['current_info'] = $user_currentinfo;
				}
				*/
				
				$r['roles'] = $user->roles;
				
				/*
				$r['roles'] = array();
				$r['roles']['role'] = $user->roles;
				$r['roles']['allcaps'] = $user->allcaps;
				$r['roles']['cap_key'] = $user->cap_key;
				*/
				
				/*
				if($_SERVER['REMOTE_ADDR'] != '' && $_SERVER['REMOTE_ADDR'] != '::1'){
				}
				*/
				
				/*
				if(current_user_can('manage_options')){ # --- admin/superadmin
				}
				if(current_user_can('read')){ # --- all
				}
				*/
				
			}
			
		}
		
		/*
		if(!is_user_logged_in()){
		}
		if(get_option('users_can_register')){
		}
		*/
		
		return $r;
		
	}
	
	if(!class_exists('geoPlugin')){
		require_once __INAMBAUPDATER_PATH__.'/includes/vendors/class-geoplugin.php';
	}
	
	function inambaupdater___geolocation(){
		
		$r = array();
		
		$r['ip'] = $_SERVER['REMOTE_ADDR'];
		$r['isp_provider'] = gethostbyaddr($_SERVER['REMOTE_ADDR']);
		
		if($_SERVER['HTTP_HOST'] != 'localhost:8888'){
			
			$geoplugin = new geoPlugin();
			$geoplugin->locate();

			if($geoplugin->countryName != ''){

				$r['country'] = $geoplugin->countryName;

				$r['city'] = $geoplugin->city;
				$r['region'] = $geoplugin->region;
				$r['regionCode'] = $geoplugin->regionCode;
				$r['regionName'] = $geoplugin->regionName;
				$r['countryCode'] = $geoplugin->countryCode;
				$r['continentCode'] = $geoplugin->continentCode;
				$r['continentName'] = $geoplugin->continentName;
				$r['latitude'] = $geoplugin->latitude;
				$r['longitude'] = $geoplugin->longitude;
				$r['locationAccuracyRadius'] = $geoplugin->locationAccuracyRadius;
				$r['timezone'] = $geoplugin->timezone;
				$r['currencyCode'] = $geoplugin->currencyCode;
				$r['currencySymbol'] = $geoplugin->currencySymbol;

			}
			
		}
		
		return $r;
		
	}
