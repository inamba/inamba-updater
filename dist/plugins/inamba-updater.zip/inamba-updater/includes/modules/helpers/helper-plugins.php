<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Module\Helpers
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	https://developer.wordpress.org/reference/functions/get_file_data/
	https://developer.wordpress.org/plugins/plugin-basics/header-requirements/
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	function inambaupdater___headers_builder($file){
		
		$r = false;
		
		if($file){
			
			$r = array();
			$filedata = get_file_data($file, inambaupdater___extra_headers());
			
			foreach($filedata as $header_name => $header_value){
				if(isSet($header_value) && $header_value != ''){
					
					$r[$header_name] = $header_value;
					
				}
			}
			
		}
		
		return $r;
		
	}
	
	function inambaupdater___extra_headers(){
		
		$headers['name'] = 'Plugin Name';
		$headers['text_domain'] = 'Text Domain';
		$headers['version'] = 'Version';
		
		/*
		$headers['name'] = 'Plugin Name';
		$headers['version'] = 'Version';
		$headers['stable_tag'] = 'Stable tag';
		$headers['requires_php'] = 'Requires PHP';
		$headers['requires_at_least'] = 'Requires at least';
		$headers['description'] = 'Description';
		$headers['author'] = 'Author';
		$headers['author_uri'] = 'Author URI';
		$headers['plugin_uri'] = 'Plugin URI';
		$headers['tested_up_to'] = 'Tested up to';
		
		$headers['Page Name'] = 'Page Name';
		$headers['Preview Image'] = 'Preview Image';
		$headers['Template File'] = 'Template File';
		*/
		
		$headers['@package'] = '@package';
		$headers['@subpackage'] = '@subpackage';
		$headers['@link'] = '@link';
		$headers['@copyright'] = '@copyright';
		$headers['@support'] = '@support';
		$headers['@since'] = '@since';
		$headers['@updated'] = '@updated';
		
		$headers['@comments'] = '@comments';
		
		$headers['@github'] = '@github';
		$headers['@github_author'] = '@github_author';
		$headers['@github_branch'] = '@github_branch';
		$headers['@github_issues'] = '@github_issues';
		
		$headers['@facebook'] = '@facebook';
		$headers['@instagram'] = '@instagram';
		$headers['@twitter'] = '@twitter';
		$headers['@linkedin'] = '@linkedin';
		$headers['@whatsapp'] = '@whatsapp';
		
		return $headers;
		
	}
	
	function inambaupdater___plugin_info(){
		
		add_filter('extra_plugin_headers', 'inambaupdater___extra_headers', 99, 1);
		$plugin_data = get_plugin_data(__INAMBAUPDATER_PATH__.__INAMBAUPDATER_NAMESPACE__.'.php');
		remove_filter('extra_plugin_headers', 'inambaupdater___extra_headers', 99, 1);
		
		return $plugin_data;
		
	}
	
	function inambaupdater___get_roles(){
		
		global $wp_roles;
		$roles = array();

		foreach($wp_roles->roles as $role => $details){
			if($role === 'administrator'){
				continue;
			}
			$roles[$role] = $details['name'];
		}

		return $roles;

	}
	
	
