<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Module\Helpers
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	/*
	$inambaupdater___globals = inambaupdater___globals();
	*/
	
	function inambaupdater___devices_os_detect(){
		
		$browser = array("IE","OPERA","MOZILLA","NETSCAPE","FIREFOX","SAFARI","CHROME");
		$os = array("WIN","MAC","LINUX");
		
		$info['browser'] = "OTHER";
		$info['os'] = "OTHER";
		
		foreach($browser as $parent){
			$s = strpos(strtoupper($_SERVER['HTTP_USER_AGENT']), $parent);
			$f = $s + strlen($parent);
			$version = substr($_SERVER['HTTP_USER_AGENT'], $f, 15);
			$version = preg_replace('/[^0-9,.]/','',$version);
			if($s){
				$info['browser'] = $parent;
				$info['version'] = $version;
			}
		}
		
		foreach($os as $val){
			if (strpos(strtoupper($_SERVER['HTTP_USER_AGENT']),$val)!==false)
			$info['os'] = $val;
		}
		
		return $info;
		
	}
	
	function inambaupdater___globals(){
		
		$os_detect = inambaupdater___devices_os_detect();
		
		$r = array();
		
		$r["browser"] = NULL;
		$r["device"] = NULL;
		
		if(strstr($_SERVER['HTTP_USER_AGENT'],'iPhone')){
		  $r["device"] = "iPhone";
		}
		else
		if(strstr($_SERVER['HTTP_USER_AGENT'],'iPad')){
		  $r["device"] = "iPad";
		}
		else
		if(strstr($_SERVER['HTTP_USER_AGENT'],'iPod')){
		  $r["device"] = "iPod";
		}
		else
		if(strstr($_SERVER['HTTP_USER_AGENT'],'Android')){
		  $r["device"] = "Android";
		  $r["browser"] = "Android";
		}
		else
		if(strstr($_SERVER['HTTP_USER_AGENT'],'webOS')){
		  $r["device"] = "webOS";
		  $r["browser"] = "webOS";
		}
		else{
		  $r["device"] = "web";
		}
		
		if(strstr($_SERVER["HTTP_USER_AGENT"], "MSIE")){
		  $r["browser"] = "MSIE";
		}
		else
		if(strstr($_SERVER["HTTP_USER_AGENT"], "Opera")){
		  $r["browser"] = "Opera";
		}
		else
		if(strstr($_SERVER["HTTP_USER_AGENT"], "Chrome")){
		  $r["browser"] = "Chrome";
		}
		else
		if(strstr($_SERVER["HTTP_USER_AGENT"], "Firefox")){
		  $r["browser"] = "Firefox";
		}
		else
		if(strstr($_SERVER["HTTP_USER_AGENT"], "Safari")){
		  $r["browser"] = "Safari";
		}
		else
		if(strstr($_SERVER["HTTP_USER_AGENT"], "Symbian")){
		  $r["browser"] = "Symbian";
		}
		else{
		  $r["browser"] = "none";
		}
		
		if($os_detect["os"] != ""){
			
			if($os_detect["os"] == "MAC"){
				$r["os"] = "Mac";
			}
			if($os_detect["os"] == "WIN"){
				$r["os"] = "Windows";
			}
			if($os_detect["os"] == "LINUX"){
				$r["os"] = "Linux";
			}
			if($os_detect["os"] == "OTHER"){
				$r["os"] = "Other";
			}
			
		}
		
		$r["browser_version"] = $os_detect["version"];
		$r["browser_lang"] = substr($_SERVER["HTTP_ACCEPT_LANGUAGE"],0,2);
		$r["port"] = $_SERVER['SERVER_PORT'];
		$r["ip"] = $_SERVER['REMOTE_ADDR'];
		$r["uri"] = $_SERVER['REQUEST_URI'];
		$r["user_agent"] = $_SERVER['HTTP_USER_AGENT'];
		
		$r['host_provider'] = gethostbyaddr($_SERVER['REMOTE_ADDR']);
		
		return $r;
		
	}
