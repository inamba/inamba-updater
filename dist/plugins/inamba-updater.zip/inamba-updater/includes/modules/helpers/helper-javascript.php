<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Module\Helpers
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	function inambaupdater___js_redirect($value){
		
		$n = "\n";
		
		if($value != ''){
			echo "<script>".$n;
			echo "var URLactual = window.location;".$n;
			echo "top.window.location = '".$value."';".$n;
			echo "</script>".$n;
		}
		
	}
	
	function inambaupdater___js_redirect_timeout($value, $timeout){
		
		if($value != ''){
			
			$wait = 3000;
			
			if($timeout != ''){
				$wait = $timeout;
			}
			
			echo '<script>';
			echo 'window.setTimeout(function () {';
			echo 'location.href = "'.$value.'";';
			echo '}, '.$wait.');';
			echo '</script>';
			
		}
		
	}
