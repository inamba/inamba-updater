<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Module\Helpers
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	require_once (dirname(__FILE__).'/helper-devices.php');
	
	/*
	require_once (dirname(__FILE__).'/helper-handlers.php');
	require_once (dirname(__FILE__).'/helper-parser.php');
	require_once (dirname(__FILE__).'/helper-settings.php');
	*/
	
	require_once (dirname(__FILE__).'/helper-builders.php');
	require_once (dirname(__FILE__).'/helper-javascript.php');
	require_once (dirname(__FILE__).'/helper-wordpress.php');
	require_once (dirname(__FILE__).'/helper-users.php');
	require_once (dirname(__FILE__).'/helper-plugins.php');
