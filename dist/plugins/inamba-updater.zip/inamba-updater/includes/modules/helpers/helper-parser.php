<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Module\Helpers
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	function inambaupdater___parse_links($string){
		
		$out = '';
		$nbd = '';
		$clausula = '';
		$var = '';
		$var = substr($string, 1, strlen($string));
		
		$result_http = strpos($string, 'http://');
		$result_https = strpos($string, 'https://');
		
		if($result_http !== false || $result_https !== false){
			$out = '<a href="'.$string.'" rel="nofollow noreferrer" target="_blank">'.$string.'</a>';
		}
		
		return $out;
		
	}
	
	function inambaupdater___parse_init($string){
		
		/*
		
		https://www.php.net/manual/es/function.str-replace.php
		https://www.anerbarrena.com/php-str_replace-4695/
		
		*/
		
		$out = '';
		$palabras = explode(' ', $string);
		
		for($a = 0; $a < count($palabras); $a++){
			
			if(strlen($palabras[$a]) != 0){
				
				if($palabras[$a][0] == '@'){
					$string_out = $palabras[$a];
					$string_builded = str_replace('@', '', $string_out);
					//$out .= '<span class="theconsole-bugs-category">'.$string_builded.'<span>';
					$out .= '<span>'.$string_builded.'<span>';
				}
				else
				if($palabras[$a][0] == '#'){
					$out .= ''.$palabras[$a].'';
				}
				else
				if(strlen($palabras[$a]) >= 7 && substr($palabras[$a],0, 7) == 'http://'){
					$out .= inambaupdater___parse_links($palabras[$a])." ";
				}
				else
				if(strlen($palabras[$a]) >= 8 && substr($palabras[$a],0, 8) == 'https://'){
					$out .= inambaupdater___parse_links($palabras[$a])." ";
				}
				else{
					$out .= $palabras[$a].' ';
				}
				
			}
			
		}
		
		return $out;
		
	}
