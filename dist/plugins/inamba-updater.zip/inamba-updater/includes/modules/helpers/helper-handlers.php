<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Module\Helpers
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	https://www.php.net/manual/es/function.filesize.php
	https://stackoverflow.com/questions/5501427/php-filesize-mb-kb-conversion
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
    function inambaupdater___log_format_size_units($bytes){
        
        $space = '&nbsp;';
        
		if($bytes >= 1073741824){
            $bytes = number_format($bytes / 1073741824, 2).$space.'GB';
        }
        elseif($bytes >= 1048576){
            $bytes = number_format($bytes / 1048576, 2).$space.'MB';
        }
        elseif($bytes >= 1024){
            /*
			$bytes = number_format($bytes / 1024, 2).$space.'KB';
            */
			$bytes = number_format($bytes / 1024).$space.'KB';
        }
        elseif($bytes > 1){
            $bytes = $bytes.$space.'bytes';
        }
        elseif($bytes == 1){
            $bytes = $bytes.$space.'byte';
        }
        else{
            $bytes = '0'.$space.'bytes';
        }
		
        return $bytes;
		
	}
