<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Module\Helpers
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	add_action('admin_menu', 'inambaupdater___extended_settings');
	
	function inambaupdater___extended_settings(){
		
		/*
		add_options_page(__('All settings', __INAMBAUPDATER_NAMESPACE__), __('All settings', __INAMBAUPDATER_NAMESPACE__), 'administrator', 'options.php');
		*/
		
		$text = _x('All settings', 'module-helper', __INAMBAUPDATER_NAMESPACE__);
		
		add_options_page($text, $text, 'administrator', 'options.php');
		
	}
	
