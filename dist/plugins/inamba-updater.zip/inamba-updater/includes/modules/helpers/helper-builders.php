<?php
	
	/*
	
	@package:			Inamba\Updater
	@subpackage:		Inamba\Updater\Module\Helpers
	@since:				1.0
	@updated:			2022-00-00 00:00
	@comments:			
	
	*/
	
	if(!defined('WPINC')){
		exit;
	}
	
	function inambaupdater___build_token(){
		
		$length = 18;
		
		$source = '';
		$source .= 'abcdefghijklmnopqrstuvwxyz';
		$source .= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$source .= '1234567890';
		
		if($length > 0){
			
			$rstr = "";
			$source = str_split($source, 1);
			
			for($i = 1; $i <= $length; $i++){
				
				mt_srand((double)microtime() * 1000000);
				$num = mt_rand(1,count($source));
				$rstr .= $source[$num-1];
				
			}
			
		}
		
		$r = $rstr;
		
		return $r;
		
	}
	
