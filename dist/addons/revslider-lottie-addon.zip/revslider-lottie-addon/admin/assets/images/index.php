<?php // Silence is golden
?>